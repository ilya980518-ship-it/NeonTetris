package com.example.neontetris

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.random.Random

private const val W = 10
private const val H = 20
private val pieces = listOf(
    listOf(0 to 0, 1 to 0, 2 to 0, 3 to 0),
    listOf(0 to 0, 1 to 0, 0 to 1, 1 to 1),
    listOf(1 to 0, 0 to 1, 1 to 1, 2 to 1),
    listOf(0 to 0, 0 to 1, 0 to 2, 1 to 2),
    listOf(1 to 0, 1 to 1, 0 to 2, 1 to 2),
    listOf(2 to 0, 0 to 1, 1 to 1, 2 to 1),
    listOf(1 to 0, 2 to 0, 0 to 1, 1 to 1)
)
private val neon = listOf(
    Color(0xFF00E5FF), Color(0xFFFFEA00), Color(0xFFFF3DAB),
    Color(0xFF9C4DFF), Color(0xFF00F5A0), Color(0xFFFF8A00), Color(0xFF4D7CFE)
)

private data class Falling(val type: Int, val x: Int = 3, val y: Int = 0, val rotation: Int = 0) {
    fun cells(): List<Pair<Int, Int>> {
        var pts = pieces[type]
        repeat(rotation) { pts = pts.map { (x, y) -> (2 - y) to x } }
        val minX = pts.minOf { it.first }; val minY = pts.minOf { it.second }
        return pts.map { (x, y) -> (this.x + x - minX) to (this.y + y - minY) }
    }
}

private class Game {
    val board = Array(H) { IntArray(W) { -1 } }
    var current by mutableStateOf(Falling(Random.nextInt(pieces.size)))
    var score by mutableIntStateOf(0)
    var lines by mutableIntStateOf(0)
    var over by mutableStateOf(false)
    var paused by mutableStateOf(false)
    var best by mutableIntStateOf(0)

    fun valid(p: Falling): Boolean = p.cells().all { (x, y) ->
        x in 0 until W && y < H && (y < 0 || board[y][x] == -1)
    }
    fun spawn() {
        current = Falling(Random.nextInt(pieces.size))
        if (!valid(current)) over = true
    }
    fun move(dx: Int, dy: Int): Boolean {
        val next = current.copy(x = current.x + dx, y = current.y + dy)
        if (valid(next)) { current = next; return true }
        return false
    }
    fun rotate() {
        val next = current.copy(rotation = (current.rotation + 1) % 4)
        if (valid(next)) current = next
    }
    fun tick() {
        if (over || paused) return
        if (!move(0, 1)) lock()
    }
    fun drop() {
        if (over || paused) return
        while (move(0, 1)) {}
        lock()
    }
    private fun lock() {
        current.cells().forEach { (x, y) -> if (y in 0 until H && x in 0 until W) board[y][x] = current.type }
        var cleared = 0
        for (y in H - 1 downTo 0) {
            if (board[y].all { it >= 0 }) {
                for (yy in y downTo 1) board[yy] = board[yy - 1].clone()
                board[0] = IntArray(W) { -1 }
                cleared++; 
                // Recheck this row after shifting.
                if (y < H) { /* loop index naturally continues */ }
            }
        }
        if (cleared > 0) {
            lines += cleared
            score += when (cleared) { 1 -> 100; 2 -> 300; 3 -> 500; else -> 800 } * (1 + (lines / 10))
        }
        spawn()
    }
    fun restart() {
        for (y in 0 until H) for (x in 0 until W) board[y][x] = -1
        score = 0; lines = 0; over = false; paused = false
        spawn()
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("neon_tetris", MODE_PRIVATE)
        setContent {
            val game = remember { Game().also { it.best = prefs.getInt("best", 0) } }
            LaunchedEffect(game) {
                while (true) {
                    delay((520L - (game.lines / 10) * 45L).coerceAtLeast(100L))
                    if (!game.paused && !game.over) {
                        game.tick()
                        if (game.score > game.best) {
                            game.best = game.score
                            prefs.edit().putInt("best", game.best).apply()
                        }
                    }
                }
            }
            NeonScreen(game,
                onMove = { game.move(it, 0) },
                onRotate = { game.rotate() },
                onDown = { game.tick() },
                onDrop = { game.drop() },
                onRestart = { game.restart() },
                onPause = { game.paused = !game.paused }
            )
        }
    }
}

@Composable
private fun NeonScreen(
    game: Game, onMove: (Int) -> Unit, onRotate: () -> Unit,
    onDown: () -> Unit, onDrop: () -> Unit, onRestart: () -> Unit, onPause: () -> Unit
) {
    val bg = Color(0xFF080B18)
    Surface(Modifier.fillMaxSize(), color = bg) {
        Column(
            Modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("NEON TETRIS", color = Color(0xFF00E5FF), fontSize = 27.sp)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                Stat("SCORE", game.score.toString())
                Stat("BEST", game.best.toString())
                Stat("LINES", game.lines.toString())
            }
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxHeight().aspectRatio(W.toFloat() / H)) {
                    val cw = size.width / W
                    val ch = size.height / H
                    for (y in 0 until H) for (x in 0 until W) {
                        val id = game.board[y][x]
                        val active = game.current.cells().any { it.first == x && it.second == y }
                        val color = if (active) neon[game.current.type] else if (id >= 0) neon[id] else Color(0xFF141A2D)
                        drawRoundRect(
                            color = color,
                            topLeft = Offset(x * cw + 1.5f, y * ch + 1.5f),
                            size = androidx.compose.ui.geometry.Size(cw - 3f, ch - 3f),
                            cornerRadius = androidx.compose.ui.geometry.CornerRadius(5f)
                        )
                        if (id >= 0 || active) drawRoundRect(
                            color = Color.White.copy(alpha = .38f),
                            topLeft = Offset(x * cw + 2f, y * ch + 2f),
                            size = androidx.compose.ui.geometry.Size(cw - 4f, ch - 4f),
                            cornerRadius = androidx.compose.ui.geometry.CornerRadius(5f),
                            style = Stroke(1.2f)
                        )
                    }
                    drawRoundRect(Color(0xFF00E5FF).copy(alpha = .65f), style = Stroke(2f))
                }
                if (game.over || game.paused) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(if (game.over) "ИГРА ОКОНЧЕНА" else "ПАУЗА", color = Color.White, fontSize = 22.sp)
                        if (game.over) Text("Счёт: ${game.score}", color = Color(0xFF00E5FF))
                    }
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                Stat("LEVEL", (1 + game.lines / 10).toString())
                Text("Управление", color = Color(0xFF8A96B8), fontSize = 14.sp)
                Text("OFFLINE", color = Color(0xFF00F5A0), fontSize = 12.sp)
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GameButton("◀", Modifier.weight(1f)) { onMove(-1) }
                GameButton("↻", Modifier.weight(1f)) { onRotate() }
                GameButton("▶", Modifier.weight(1f)) { onMove(1) }
                GameButton("▼", Modifier.weight(1f)) { onDown() }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GameButton("DROP", Modifier.weight(1f)) { onDrop() }
                GameButton(if (game.paused) "ПРОДОЛЖИТЬ" else "ПАУЗА", Modifier.weight(1f)) { onPause() }
                GameButton("ЗАНОВО", Modifier.weight(1f)) { onRestart() }
            }
            if (game.over) Text("Нажми «ЗАНОВО», чтобы сыграть ещё раз", color = Color(0xFFFF3DAB), fontSize = 12.sp)
        }
    }
}

@Composable
private fun Stat(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, color = Color(0xFF8792B2), fontSize = 10.sp)
        Text(value, color = Color.White, fontSize = 19.sp)
    }
}

@Composable
private fun GameButton(label: String, modifier: Modifier, action: () -> Unit) {
    Button(
        onClick = action, modifier = modifier.height(52.dp),
        shape = RoundedCornerShape(13.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF18213B), contentColor = Color(0xFF00E5FF)),
        contentPadding = PaddingValues(2.dp)
    ) { Text(label, fontSize = 15.sp) }
}
